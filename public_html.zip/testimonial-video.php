<?php 

$title="Testimonial Video- My Assistant Services";
$discription ="My Assiatnt Client provide video testimonial is a video of a customer or client praising a company.";
$keyword ="Personal virtual assistant, remotework assistant service, virtual personal assistant services.";
$canonical="https://www.myassistantservices.com/testimonial-video.php";


include 'includes/header.php' 

?>

<section class="about-page">
     <h3>Our Happy Clients</h3>
</section>


<section class="virtual-content">

    <div class="container testimonial-page">
        
         
        <div class="row mb-5" >
            
            <div class="col-xl-6 col-lg-6 col-md-6 mt-3">
               <img src="assets/images/quote.png" alt="testimonial video " class="img-fluid" width="35px">
               
               <figure>
  <blockquote class="blockquote mt-3">
    <h5 style="line-height: 1.60;"> “ Client Testimonial of Anthony Marotta about our Virtual Assistant Services- My Assistant Services.</h5>
  </blockquote>
 <!-- <figcaption class="blockquote-footer mt-3">
    Someone famous in <cite title="Source Title">Source Title</cite>
  </figcaption>--->
</figure>

             
            </div>
      
        
             <div 
             
             class="col-xl-6 col-lg-6">
                <iframe width="100%" height="310" src="https://www.youtube.com/embed/YylinRDqtSk?start=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
                
        </div>
        
 <!-- ------------------------------------------------------------------------------------ --->     
        
     
         
              
    
       <!--- <div class="row" style="margin-top:80px;">
            
              <div class= "col-xl-6 col-lg-6 col-md-12 ">
                <iframe width="100%" height="310" src="https://www.youtube.com/embed/omsW5qlxVl4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
            <div class="col-xl-6 col-lg-6">
               <img src="assets/images/quote.png" alt="" class="img-fluid" width="35px">
               <h5 class="mt-4" style="line-height: 1.60;">
                   “ Excellent Experience with My Virtual Assistant Services Excellent Experience with My Virtual Assistant Services.
               </h5>
            </div>
            
        </div>---->
       
     <!-- ----------------------------------------------------------------------------------------------------------------- -->
       
    <!--- <div class="row" style="margin-top:80px;" >
            
            <div class="col-xl-6 col-lg-6 col-md-6 mt-3">
               <img src="assets/images/quote.png" alt="" class="img-fluid" width="35px">
               
               <figure>
  <blockquote class="blockquote mt-3">
    <h5 style="line-height: 1.60;"> “ Client Testimonial of Shanae about our Virtual Assistant Services- My Assistant Services.</h5>
  </blockquote>
  <figcaption class="blockquote-footer mt-3">
    Someone famous in <cite title="Source Title">Source Title</cite>
  </figcaption>
</figure>

             
            </div>
             <div class="col-xl-6 col-lg-6">
                <iframe width="100%" height="310" src="https://www.youtube.com/embed/fmyM-pIY5-8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
                
        </div>--->
 <!-- ------------------------------------------------------------------------------------------------------- -->      
        
        <div class="row" style="margin-top:80px;">
            
              <div class="col-xl-6 col-lg-6">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/i21tp0pVgm4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
            <div class="col-xl-6 col-lg-6 p-2">
               <img src="assets/images/quote.png" alt="client review" class="img-fluid" width="35px">
               <h5 class="mt-4" style="line-height: 1.60;">
                   “ Client Testimonial of Michale Mancuso about our Virtual Assistant Services- My Assistant Services.
               </h5>
            </div>
               
        </div>
 <!---    ----------------------------------------------------------------------------------------------------  -->        
   <div class="row" style="margin-top:80px;" >
            
            <div class="col-xl-6 col-lg-6 col-md-6 mt-3">
               <img src="assets/images/quote.png" alt="client testimonial" class="img-fluid" width="35px">
               
               <figure>
  <blockquote class="blockquote mt-3">
    <h5 style="line-height: 1.60;"> “ Client Testimonial of Nick Hedberg about our Virtual Assistant Services- My Assistant Services.</h5>
  </blockquote>
  <!---<figcaption class="blockquote-footer mt-3">
    Someone famous in <cite title="Source Title">Source Title</cite>
  </figcaption>--->
</figure>

             
            </div>
             <div class="col-xl-6 col-lg-6">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/iBWES8um15o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
                
        </div>
 
 
  <!    ---------------------------------------------------------------------------------------------------  ->
 
 <div class="row" style="margin-top:80px;">
            
              <div class="col-xl-6 col-lg-6">
                <iframe width="100%" height="310" src="https://www.youtube.com/embed/te-hvj3Xbhs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
            <div class="col-xl-6 col-lg-6 p-2">
               <img src="assets/images/quote.png" alt="testimonial" class="img-fluid" width="35px">
               <h5 class="mt-4" style="line-height: 1.60;">
                   “ Client Testimonial of Devin about our Virtual Assistant Services- My Assistant Services.
               </h5>
            </div>
               
        </div>
 
 
 <!-- ----------------------------------------------------------------->
        
         <div class="row" style="margin-top:80px;" >
            
            <div class="col-xl-6 col-lg-6 col-md-6 mt-3">
               <img src="assets/images/quote.png" alt="virtual client review" class="img-fluid" width="35px">
               
               <figure>
  <blockquote class="blockquote mt-3">
    <h5 style="line-height: 1.60;"> “ Client Testimonial of Christine Jones about our Virtual Assistant Services- My Assistant Services.</h5>
  </blockquote>
 <!--- <figcaption class="blockquote-footer mt-3">
    Someone famous in <cite title="Source Title">Source Title</cite>
  </figcaption>--->
</figure>

             
            </div>
             <div class="col-xl-6 col-lg-6">
                <iframe width="100%" height="310" src="https://www.youtube.com/embed/h5OcCoeXoIA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
                
        </div>
 
  <!-------------------------------------------------------------------->
  
  <div class="row" style="margin-top:80px;">
            
              <div class="col-xl-6 col-lg-6">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/Iqa8YZ4G-kI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
            <div class="col-xl-6 col-lg-6 p-2">
               <img src="assets/images/quote.png" alt="client feedback" class="img-fluid" width="35px">
               <h5 class="mt-4" style="line-height: 1.60;">
                   “ If you need any sort of help, she specializes in much more than just research and she's very good at what she does definitely recommend her. And I know that I'm going to be using her again in the future. Thank you Neha.
               </h5>
            </div>
               
        </div>
        
    <!------------------------------------------------------------------------------------->    
        
        <div class="row" style="margin-top:80px;" >
            
            <div class="col-xl-6 col-lg-6 col-md-6 mt-3">
               <img src="assets/images/quote.png" alt="testimonail video for client" class="img-fluid" width="35px">
               
               <figure>
  <blockquote class="blockquote mt-3">
    <h5 style="line-height: 1.60;"> “ Client Testimonial of Shanae Walker about our Virtual Assistant Services- My Assistant Services.</h5>
  </blockquote>
  <!---<figcaption class="blockquote-footer mt-3">
    Someone famous in <cite title="Source Title">Source Title</cite>
  </figcaption>---->
</figure>

             
            </div>
             <div class="col-xl-6 col-lg-6">
             <iframe width="560" height="315" src="https://www.youtube.com/embed/fmyM-pIY5-8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
                
        </div>
     <!-------------------------------------------------------------------------------------------------->
     <div class="row" style="margin-top:80px;">
            
              <div class="col-xl-6 col-lg-6">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/vyViG-mb66Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
            <div class="col-xl-6 col-lg-6 p-2">
               <img src="assets/images/quote.png" alt="video testimonial" class="img-fluid" width="35px">
               <h5 class="mt-4" style="line-height: 1.60;">
                   “ Melinda Flynn Recommendation Video for Brendon Wilson.
               </h5>
            </div>
               
        </div>
     
     
     
     
        
    </div>

</section>





<?php include 'includes/info.php' ?>
<?php include 'includes/footer.php' ?>
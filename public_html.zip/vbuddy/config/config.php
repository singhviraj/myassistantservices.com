<?php 

$host ="localhost";
$username = "u455380687_vbuddy";
$password = "vbuddy@2022!DB";
$database = "u455380687_vbuddy";

$conn = mysqli_connect($host, $username, $password, $database);
// if($conn){
//     echo "Db Connected";
// }
// else{

//     echo "DB Not Connected";

// }



?>